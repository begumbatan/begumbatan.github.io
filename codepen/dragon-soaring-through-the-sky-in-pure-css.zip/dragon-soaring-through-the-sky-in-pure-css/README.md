# Dragon soaring through the sky, in pure CSS! 🐲

A Pen created on CodePen.io. Original URL: [https://codepen.io/chriskirknielsen/pen/QmQYPb](https://codepen.io/chriskirknielsen/pen/QmQYPb).

My partner asked me to make her a dragon, so I made her one… in CSS! Here's to you, Ilona. ❤️

Inspired by this cute shot by Matthew Wiard: https://dribbble.com/shots/2568650-Illustration